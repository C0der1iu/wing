# -*- coding: utf-8 -*-
import scrapy
from InDeed.items import IndeedItem


class InDeedSpider(scrapy.Spider):
    name = "InDeed"
    allowed_domains = ['cn.indeed.com']
    #采用拼接的方式,q后面的职位自己定义，搜索这个职位的所有招聘信息
    url = "https://cn.indeed.com/工作?q=渗透测试&start="
    add = 0
    start_urls = [url+str(add)]

    def parse(self,response):
        item = IndeedItem()
        #规则
        position_list = response.xpath('//h2/a/text()').extract()
        workplace_list = response.xpath('//span/span[@itemprop="addressLocality"]/text()').extract()
        company_list= response.xpath('//span/span[@itemprop="name"]/text()').extract()
        time_list= response.xpath('//span[@class="date"]/text()').extract()
        for q,w,e,r in zip(position_list,workplace_list,company_list,time_list):
            item['position'] = q
            item['Workingplace'] = w
            item['company'] = e
            item['Time'] = r

            yield item





        #用字符串拼接，达到翻页效果
        if self.add < 990:
            self.add +=10
            url1 = self.url + str(self.add)
            yield scrapy.Request(url1,callback =self.parse)







