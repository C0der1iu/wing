# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import sqlite3

class IndeedPipeline(object):
    def open_spider(self,spider):
        self.conn = sqlite3.connect("data.sqlite")
        self.cur = self.conn.cursor()


    def process_item(self, item, spider):
        #定义插入语句
        sql = "insert into hacker (position,Workingplace,company,Time) values('{}','{}','{}','{}')".format(item['position'],item['Workingplace'],item['company'],item['Time'])
        self.conn.execute(sql)
        self.conn.commit()

        return item

    def spider_close(self,spider):
        self.conn.close()