# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class IndeedItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    #职位
    position = scrapy.Field()
    #工作地点
    Workingplace = scrapy.Field()
    #招娉的公司
    company = scrapy.Field()
    #发布时间
    Time = scrapy.Field()

